title: String s= new String("xyz");创建多少个对象
date: '2019-08-30 17:46:53'
updated: '2019-08-30 17:49:27'
tags: [转载]
permalink: /articles/2019/08/30/1567158413149.html
---
你知道在 java 中除了 8 种基本类型外，其他的都是类对象以及其引用。所以 "xyz "在 java 中它是一个String 对象.对于 string 类对象来说他的对象值是不能修改的，也就是具有不变性。

看：
```
String s= "hello"; 
s= "Java"; 
String s1= "hello"; 
String s2=new   String( "hello");

```
结果如下图：
![image.png](https://img.hacpai.com/file/2019/08/image-e6acc283.png)


啊，s 所引用的 string 对象不是被修改了吗？之前所说的不变性，去那里了啊？

你别着急，让我告诉你说发生了什么事情： 
在 jvm 的工作过程中，会创建一片的内存空间专门存入 string 对象。我们把这片内存空间叫做 string 池。

String s = “hello “; 当 jvm 看到 “hello”，在 string 池创建 string 对象存储它，并将他的引用返回给s。 
s = “java “，当 jvm 看到 “java “，在 string 池创建新的 string 对象存储它，再把新建的 string 对象的引用返回给s。而原先的 “hello”仍然在 string 池内。没有消失，他是不能被修改的。

所以我们仅仅是改变了s的引用，而没有改变他所引用的对象，因为 string 对象的值是不能被修改的。

String s1 = “hello” ; jvm 首先在 string 池内里面看找不找得到字符串 “hello”, 如果找得到,返回他的引用给 s1，否则的话就会创建新的 string 对象，放到 string 池里。这里由于 s = “hello”了,对象已经被引用，所以依据规则 s 和 s1 都是引用同一个对象。所以 s == s1 将返回 true。( == 对于非基本类型，是比较两引用是否引用内存中的同一个对象，这里先不区分 == 和 equals 的区别 )
![image.png](https://img.hacpai.com/file/2019/08/image-ba1a4178.png)


String s2 = new String( “hello”); jvm 首先在 string 池内里面看找不找得到字符串 “hello”, 如果找得到, 不做任何事情，否则的话就会创建新的 string 对象，放到 string 池里面。由于遇到了 new，还会在内存上（不是 string 池里面）创建 string 对象存储 “hello”，并将内存上的（不是 string 池内的）string 对象返回给 s2。所以 s == s2 将返回 false，不是引用同一个对象。

![image.png](https://img.hacpai.com/file/2019/08/image-d0fb0065.png)

好现在我们看题目： 
String s = new String( “xyz “); 
首先在 string 池内找，找到？不创建 string 对象，否则创建一个对象， 
遇到 new 运算符号了，在内存上创建 string 对象，并将其返回给 s，又一个对象

所以总共是 1个 或者 2个对象 。

而为什么在网上都说 String s=new String(“xyz”); 创建了2个对象？那可能因为它就写这么一句代码，误让人默认的认为执行代码之前并不实例任何一个 String 对象过（也许 很多人不会这么想，），跟着别人或者不经思考的就说2个，斟是说存放在栈内存中专门存放 String 对象引用的 s 变量是一个对象！

————————————————
版权声明：本文为CSDN博主「zhisheng_blog」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/tzs_1041218129/article/details/69367423
