title: 《Java集合》面试题（一）
date: '2019-09-03 11:38:37'
updated: '2019-09-03 16:43:43'
tags: [面试]
permalink: /articles/2019/09/03/1567481916940.html
---
## 1.Java 集合框架的基础接口有哪些？
* Collection ，为集合层级的根接口。一个集合代表一组对象，这些对象即为它的元素。Java 平台不提供这个接口任何直接的实现。
  * Set ，是一个不能包含重复元素的集合。这个接口对数学集合抽象进行建模，被用来代表集合，就如一副牌。
  * List ，是一个有序集合，可以包含重复元素。你可以通过它的索引来访问任何元素。List 更像长度动态变换的数组。
* Map ，是一个将 key 映射到 value 的对象。一个 Map 不能包含重复的 key，每个 key 最多只能映射一个 value 。
* 一些其它的接口有 Queue、Dequeue、SortedSet、SortedMap 和 ListIterator 。
![image.png](https://img.hacpai.com/file/2019/09/image-d66cadb9.png)


## 2.为什么Map接口不继承Collection接口？
尽管 Map 接口和它的实现也是集合框架的一部分，但 Map 不是集合，集合也不是 Map。因此，Map 继承 Collection 毫无意义，反之亦然。

如果 Map 继承 Collection 接口，那么元素去哪儿？Map 包含 key-value 对，它提供抽取 key 或 value 列表集合( Collection )的方法，但是它不适合“一组对象”规范。

## 3.Collection 和 Collections 的区别？
Collection与Collections的根本区别是：

1、Collection 是一个集合接口。它提供了对集合对象进行基本操作的通用接口方法。[Collection接口](https://www.baidu.com/s?wd=Collection%E6%8E%A5%E5%8F%A3&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao)在Java 类库中有很多具体的实现。[Collection接口](https://www.baidu.com/s?wd=Collection%E6%8E%A5%E5%8F%A3&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao)的意义是为各种具体的集合提供了最大化的统一操作方式。

2、Collections 是一个包装类。它包含有各种有关集合操作的静态多态方法。此类不能实例化，就像一个工具类，服务于Java的Collection框架。

Collections 是一个包装类，Collection 表示一组对象，这些对象也称为 collection 的元素。一些 collection 允许有重复的元素，而另一些则不允许，一些 collection 是有序的，而另一些则是无序的。

## 4.集合框架底层数据结构总结

1）List

* ArrayList ：Object 数组。
* Vector ：Object 数组。
* LinkedList ：双向链表(JDK6 之前为循环链表，JDK7 取消了循环)。

2）Map

* HashMap ：
    * JDK8 之前，HashMap 由数组+链表组成的，数组是HashMap的主体，链表则是主要为了解决哈希冲突而存在的（“拉链法”解决冲突）。
    * JDK8 以后，在解决哈希冲突时有了较大的变化，当链表长度大于阈值（默认为 8 ）时，将链表转化为红黑树，以减少搜索时间。
* LinkedHashMap ：LinkedHashMap 继承自 HashMap，所以它的底层仍然是基于拉链式散列结构即由数组和链表或红黑树组成。另外，LinkedHashMap 在上面结构的基础上，增加了一条双向链表，使得上面的结构可以保持键值对的插入顺序。同时通过对链表进行相应的操作，实现了访问顺序相关逻辑。详细可以查看：[《LinkedHashMap 源码详细分析（JDK1.8）》](https://www.imooc.com/article/22931) 。
* Hashtable ：数组+链表组成的，数组是 HashMap 的主体，链表则是主要为了解决哈希冲突而存在的。
* TreeMap ：红黑树（自平衡的排序二叉树）。

3）Set

* HashSet ：无序，唯一，基于 HashMap 实现的，底层采用 HashMap 来保存元素。
* LinkedHashSet ：LinkedHashSet 继承自 HashSet，并且其内部是通过 LinkedHashMap 来实现的。有点类似于我们之前说的LinkedHashMap 其内部是基于 HashMap 实现一样，不过还是有一点点区别的。
* TreeSet ：有序，唯一，红黑树(自平衡的排序二叉树)。

## 5.什么是迭代器(Iterator)？
Iterator接口提供了很多对集合元素进行迭代的方法。每一个集合类都包括了可以返回迭代器实例的迭代方法。迭代器可以在迭代过程中删除底层集合的元素，但是不可以直接调用集合的remove(Object obj)删除，可以通过迭代器的remove()方法删除

## 6.Iterator 和 ListIterator 的区别是什么？

* Iterator 可用来遍历 Set 和 List 集合，但是 ListIterator 只能用来遍历 List。
* Iterator 对集合只能是前向遍历，ListIterator 既可以前向也可以后向。
* ListIterator 实现了 Iterator 接口，并包含其他的功能。比如：增加元素，替换元素，获取前一个和后一个元素的索引等等。

## 7.快速失败（fail-fast）和安全失败（fail-safe）的区别是什么？

差别在于 ConcurrentModification 异常：

* 快速失败：当你在迭代一个集合的时候，如果有另一个线程正在修改你正在访问的那个集合时，就会抛出一个 ConcurrentModification 异常。 在 `java.util` 包下的都是快速失败。
* 安全失败：你在迭代的时候会去底层集合做一个拷贝，所以你在修改上层集合的时候是不会受影响的，不会抛出 ConcurrentModification 异常。在 `java.util.concurrent` 包下的全是安全失败的。

具体可参考这篇文章# [快速失败(fail-fast)和安全失败(fail-safe)的区别](https://www.cnblogs.com/shamo89/p/6685216.html)

## 8.Comparable 和 Comparator 的区别?

* Comparable 接口，在 `java.lang` 包下，用于当前对象和其它对象的比较，所以它有一个 `#compareTo(Object obj)` 方法用来排序，该方法只有一个参数。
  * compareTo 方法的返回值表示
    * 大于 0 ，表示对象大于参数对象。
    * 小于 0 ，表示对象小于参数对象
    * 等于 0 ，表示两者相等。
* Comparator 接口，在 `java.util` 包下，用于传入的两个对象的比较，所以它有一个 `#compare(Object obj1, Object obj2)` 方法用来排序，该方法有两个参数。

## 9.List 和 Set 联系和区别
List，Set 都是继承自 Collection 接口。
* 顺序性与重复性：
  * List 特点：元素有放入顺序，元素可重复。
  * Set 特点：元素无放入顺序，元素不可重复，重复元素会覆盖掉。
* 循环：
  * List 支持 `for` 循环，也就是通过下标来遍历，也可以用迭代器
  * Set 只能用迭代，因为他无序，无法用下标来取得想要的值
* 插入、更新和检索效率
  * Set：检索指定的元素效率高，删除和插入效率高，插入和删除可能会引起元素位置改变。
  * List：和数组类似，List可以动态增长，通过下标查找元素的效率高，查找指定的元素效率低，插入删除指定的元素效率低，因为可能会引起其他元素位置改变

## 10.List 和 Map 区别？

* List 继承Collection接口，是对象集合，允许对象重复。
* Map 不继承Collection接口，是键值对的集合，不允许 key 重复。
