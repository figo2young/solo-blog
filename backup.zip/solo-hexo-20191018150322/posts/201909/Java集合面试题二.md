title: 《Java集合》面试题（二）
date: '2019-09-03 14:25:53'
updated: '2019-09-03 17:24:27'
tags: [面试]
permalink: /articles/2019/09/03/1567491953105.html
---
## 11.ArrayList 与 LinkedList 区别？
**ArrayList**

* 优点：ArrayList 是实现了基于动态数组的数据结构，因为地址连续，一旦数据存储好了，查询操作效率会比较高（在内存里是连着放的）。
* 缺点：因为地址连续，ArrayList 要移动数据，所以插入和删除操作效率比较低。

**LinkedList**

* 优点：LinkedList 基于链表的数据结构，地址是任意的，所以在开辟内存空间的时候不需要等一个连续的地址。对于新增和删除操作 add 和 remove ，LinedList 比较占优势。LinkedList 适用于要头尾操作或插入指定位置的场景。
* 缺点：因为 LinkedList 要移动指针，所以查询操作性能比较低。

 **适用场景分析**：

* 当需要对数据进行对随机访问的情况下，选用 ArrayList 。
    
* 当需要对数据进行多次增加删除修改时，采用 LinkedList 。
    
    > 如果容量固定，并且只会添加到尾部，不会引起扩容，优先采用 ArrayList 。
    
* 当然，绝大数业务的场景下，使用 ArrayList 就够了。主要是，注意好避免 ArrayList 的扩容，以及非顺序的插入。

## 12.ArrayList 与 Vector 区别
* ArrayList 和 Vector 都是用数组实现的，主要有这么三个区别：
1. Vector 是多线程安全的，线程安全就是说多线程访问同一代码，不会产生不确定的结果，而 ArrayList 不是。这个可以从源码中看出，Vector 类中的方法很多有 `synchronized` 进行修饰，这样就导致了 Vector 在效率上无法与 ArrayList 相比。   
2. 两个都是采用的线性连续空间存储元素，但是当空间不足的时候，两个类的增加方式是不同。  
3. Vector可以设置增长因子，而ArrayList 不可以。
* 适用场景分析：
1. Vector 是线程同步的，所以它也是线程安全的，而 ArrayList 是线程无需同步的，是不安全的。如果不考虑到线程的安全因素，一般用 ArrayList 效率比较高。
    
    > 实际场景下，如果需要多线程访问安全的数组，使用 CopyOnWriteArrayList 。
    
2. 如果集合中的元素的数目大于目前集合数组的长度时，在集合中使用数据量比较大的数据，用 Vector 有一定的优势。
    
    > 这种情况下，使用 LinkedList 更合适。

## 13.HashMap 和 Hashtable 的区别
1. 继承的父类不同:Hashtable继承自Dictionary类，而HashMap继承自AbstractMap类。但二者都实现了Map接口。
2. 线程安全性不同:javadoc中关于hashmap的一段描述如下：此实现不是同步的。如果多个线程同时访问一个哈希映射，而其中至少一个线程从结构上修改了该映射，则它必须保持外部同步。
3. 是否提供contains方法不同：Hashtable提供contains方法，HashMap提供containsKey和containsValue方法，防止混淆
4. key和value是否允许null值不同：HashMap允许null的key和value,Hashtable不允许null的key和value，会报NullPointerException
5. 两个遍历方式的内部实现上不同：Hashtable、HashMap都使用了 Iterator。而由于历史原因，Hashtable还使用了Enumeration的方式 。
6. 哈希值的使用不同：HashTable直接使用对象的hashCode。而HashMap重新计算hash值。
7. 内部实现使用的数组初始化和扩容方式不同
   * HashTable在不指定容量的情况下的默认容量为11，而HashMap为16，Hashtable不要求底层数组的容量一定要为2的整数次幂，而HashMap则要求一定为2的整数次幂。  
   * Hashtable扩容时，将容量变为原来的2倍加1，而HashMap扩容时，将容量变为原来的2倍。

## 14.HashSet 和 HashMap 的区别
1. 接口实现不同：HashMap实现了Map接口，HashSet实现了Set接口
2. 存储的对象不同：HashMap存储键值对,HashSet仅储存对象
3. 添加元素的方法不同：HashMap调用put（）向map中添加元素，HashSet调用add()向set添加元素
4. 使用的HashCode值不同：HashMap使用键（Key）计算Hashcode，并且HashMap会重新进行hash，HashSet使用成员对象来计算hashcode值，对于两个对象来说hashcode可能相同，所以equals()方法用来判断对象的相等性，如果两个对象不同的话，那么返回false

## 15.HashSet 和 TreeSet 的区别
* HashSet 是用一个 hash 表来实现的，因此，它的元素是无序的。添加，删除和 HashSet 包括的方法的持续时间复杂度是 `O(1)` 。
* TreeSet 是用一个树形结构实现的，因此，它是有序的。添加，删除和 TreeSet 包含的方法的持续时间复杂度是 `O(logn)` 。

**如何决定选用 HashMap 还是 TreeMap？**

* 对于在 Map 中插入、删除和定位元素这类操作，HashMap 是最好的选择。
* 然而，假如你需要对一个有序的 key 集合进行遍历， TreeMap 是更好的选择。

基于你的 collection 的大小，也许向 HashMap 中添加元素会更快，再将 HashMap 换为 TreeMap 进行有序 key 的遍历。

## 16.HashMap的工作原理
我们知道在 Java 中最常用的两种结构是数组和模拟指针（引用），几乎所有的数据结构都可以利用这两种来组合实现，HashMap 也是如此。实际上 HashMap 是一个“链表散列”。

HashMap 是基于 hashing 的原理。

![image.png](https://img.hacpai.com/file/2019/09/image-7b3f4ca7.png)

* 我们使用 `#put(key, value)` 方法来存储对象到 HashMap 中，使用 `get(key)` 方法从 HashMap 中获取对象。
* 当我们给 `#put(key, value)` 方法传递键和值时，我们先对键调用 `#hashCode()` 方法，返回的 hashCode 用于找到 bucket 位置来储存 Entry 对象。

## 17.hashCode 和 equals 对HashMap的影响

HashMap 使用 key 对象的 `#hashCode()` 和 `#equals(Object obj)` 方法去决定 key-value 对的索引。当我们试着从 HashMap 中获取值的时候，这些方法也会被用到。

* 如果这两个方法没有被正确地实现，在这种情况下，两个不同 Key 也许会产生相同的 `#hashCode()` 和 `#equals(Object obj)` 输出，HashMap 将会认为它们是相同的，然后覆盖它们，而非把它们存储到不同的地方。

同样的，所有不允许存储重复数据的集合类都使用 `#hashCode()` 和 `#equals(Object obj)` 去查找重复，所以正确实现它们非常重要。`#hashCode()` 和 `#equals(Object obj)` 方法的实现，应该遵循以下规则：

* 如果 `o1.equals(o2)` ，那么 `o1.hashCode() == o2.hashCode()` 总是为 `true` 的。
* 如果 `o1.hashCode() == o2.hashCode()` ，并不意味 `o1.equals(o2)` 会为 `true` 。

## 18.HashMap 的长度为什么是 2 的幂次方
为了能让 HashMap 存取高效，尽量较少碰撞，也就是要尽量把数据分配均匀，每个链表/红黑树长度大致相同。这个实现就是把数据存到哪个链表/红黑树中的算法。

这个算法应该如何设计呢？我们首先可能会想到采用 `%` 取余的操作来实现。但是，重点来了：

* 取余(`%`)操作中如果除数是 2 的幂次则等价于与其除数减一的与(`&`)操作（也就是说 `hash % length == hash & (length - 1)` 的前提是 length 是 2 的 n 次方；）。
* 并且，采用二进制位操作 `&`，相对于 `%` 能够提高运算效率，

这就解释了 HashMap 的长度为什么是 2 的幂次方。
